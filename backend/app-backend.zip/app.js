//importing modules
const express = require('express')
const sequelize = require('sequelize')
const dotenv = require('dotenv').config()
const cookieParser = require('cookie-parser')
const db = require('./Models')
const userRoutes = require('./Routes/userRoutes')
const productRoutes = require('./Routes/productRoutes')
const transactionRoutes = require('./Routes/transactionRoutes')

//setting up your port
const PORT = process.env.PORT || 8080;

//assigning the variable app to express
const app = express()

//middleware
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(cookieParser())

db.sequelize.sync({force:true}).then(()=>{
    console.log('db in sync...');
})

app.use('/api/users',userRoutes);
app.use('/api/products',productRoutes);
app.use('/api/transactions',transactionRoutes);



//listening to server connection
app.listen(PORT, () => console.log(`Server is connected on ${PORT}`))
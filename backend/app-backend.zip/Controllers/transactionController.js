//importing modules
const db = require("../Models");
const { Op } = require("sequelize");
// Assigning users to the variable User
const Transaction = db.transactions;

const addTransaction=async(req,res) =>{
    //req = {product_id,date,price,apikey,selldata,buydata,case,user_id}
    //check case
    //middleware validity
    //check if product exist - {prodid}
    //check if transactionexist-{prodid and date}
    //no exist add


    //date protection
    const{product_id,transaction_date,price,apikey,selldata,buydata,user_id}=req.body;
    const data={
        product_id:product_id,
        transaction_date:transaction_date,
        price:price,
        apikey:apikey,
        selldata:selldata,
        buydata:buydata,
        user_id:user_id
    }
    const transactionsPreCheck = await Transaction.findAll({
        where:{
            [Op.and]:[{product_id:product_id},{apikey:apikey},{transaction_date:transaction_date}]
        }
    })
    console.log(transactionsPreCheck,"pre check")
    if(transactionsPreCheck && transactionsPreCheck.length!=0){
       return res.status(401).send("Transaction failed. Data already present");
    }

    const transaction = await Transaction.create(data);
    if(transaction){
        return res.status(201).send(transaction);

    }
    else{
        return res.status(409).send("Details are not correct");

    }



}
const getTransactions = async(req,res) =>{
   try{ const {user_id,apikey}=req.body
    const transactions = await Transaction.findAll({
        where:{
            [Op.and]:[{user_id:user_id},{apikey:apikey}]
        }
    })
    if(transactions&&transactions.length>0){
        return res.status(201).send(transactions);
        
    }
    else{
        return res.status(409).send("Server security callback");

    }

}
    catch(err){
        console.log("Treansaction fetch server Error",err);
    }
}
const updateTransaction =async(req,res) =>{
    try{

    
    const {product_id,apikey,transaction_date,selldata,buydata,updateCase}=req.body;
    const transactions = await Transaction.findAll({
        where:{
            [Op.and]:[{product_id:product_id},{apikey:apikey}]
        }
    })
    if(!transactions){
        return res.status(409).send("Server security callback:False update case");
        
    }
    if(updateCase==0){
        await Transaction.update({ selldata: selldata }, {
            where: {
            [Op.and]:[{product_id:product_id},{apikey:apikey},{transaction_date:transaction_date}]
              
            }
          });
       return res.status(201).send("Updated");

    }
    else if(updateCase==1){
        await Transaction.update({ buydata: buydata }, {
            where: {
            [Op.and]:[{product_id:product_id},{apikey:apikey},{transaction_date:transaction_date}]
              
            }
          });
       return res.status(201).send("Updated");

    }
    else if(updateCase==2){
        await Transaction.update({buydata:buydata,selldata:selldata}, {
            where: {
            [Op.and]:[{product_id:product_id},{apikey:apikey},{transaction_date:transaction_date}]
              
            }
          });
       return res.status(201).send("Updated");

    }
    else{
        return res.status(409).send("Server security callback:False update case");
        
    }
}catch(err){
    console.log(err);
}
    

}
module.exports = {
addTransaction,getTransactions,updateTransaction
};
//importing modules
const bcrypt = require("bcrypt");
const db = require("../Models");
const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
// Assigning users to the variable User
const Product = db.products;
//2023-09-19T13:09:08.688Z
const addProduct=async(req,res) =>{
    try{
        const {name,description,user_id,apikey}=req.body;
        const data={
            name:name,
            description:description,
            user_id:user_id,
            apikey:apikey,
        }
        const product = await Product.create(data);
        if(product){
            return res.status(201).send(product);
        }
        else{
            return res.status(409).send("Incorrect details");
             
        }
    }catch(err){
        console.log("Product server error",err);

    }

 


}
const getProducts =async(req,res) =>{
    try{
        const {user_id,apikey}=req.body;
        const products = await Product.findAll({
            where:{
                [Op.and]:[{user_id:user_id},{apikey:apikey}]
            }
        })
        if(products){
            return res.status(201).send(products);
            
        }
        else{
            return res.status(409).send("Server security callback");

        }
    }
    catch(err){
        console.log("Product fetch server error",err);
    }

}
module.exports = {
 addProduct,
 getProducts
};

module.exports=(sequelize,DataTypes) =>{
    const Product=sequelize.define("products",{
        product_id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,
            autoIncrement: true,
        },
        name:{
            type:DataTypes.STRING,
            allowNull:false
        },
        description:{
            type:DataTypes.STRING,
            allowNull:false
        },
        user_id:{
            type:DataTypes.INTEGER,
            allowNull:false
        },
        apikey:{
            type:DataTypes.STRING,
            allowNull:false
        },
        
    },{timestamps:true},)
    return Product
}
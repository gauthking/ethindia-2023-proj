const {Sequelize,DataTypes} = require('sequelize');


module.exports=(sequelize,DataTypes) =>{
    const User=sequelize.define("users",{
        user_id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,
            autoIncrement: true,
        },
        username:{
            type:DataTypes.STRING,
            allowNull:false
        },
        email:{
            type:DataTypes.STRING,
            allowNull:false
        },
        password_hash:{
            type:DataTypes.STRING,
            allowNull:false
        },
        name:{
            type:DataTypes.STRING,
            allowNull:false
        },
        apikey:{
            type:DataTypes.STRING,
            allowNull:false
        },
    },{timestamps:true},)
    return User
}
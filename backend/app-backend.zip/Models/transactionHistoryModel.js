const { sequelize } = require(".");

module.exports=(sequelize,DataTypes) =>{
    const Transaction=sequelize.define("transaction_histories",{
        transaction_id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,
            autoIncrement: true,

        },
        product_id:{
            type:DataTypes.INTEGER,
            allowNull:false
        },
        transaction_date:{
            type:DataTypes.STRING,
            allowNull:false
        },
        price:{
            type:DataTypes.DECIMAL(10,2),
            allowNull:false
        },
        apikey:{
            type:DataTypes.STRING,
            allowNull:false
        },
        selldata:{
            type:DataTypes.DECIMAL(10,2),
            allowNull:false
        },
        buydata:{
            type:DataTypes.DECIMAL(10,2),
            allowNull:false
        },
        user_id:{
            type:DataTypes.INTEGER
        }


        
        
    },{timestamps:true},)
    return Transaction
}
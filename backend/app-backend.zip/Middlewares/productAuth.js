//importing modules
const express = require("express");
const db = require("../Models");
//Assigning db.users to User variable
 const Product = db.products;
 const { Op } = require("sequelize");
 const verifyProduct = async(req,res,next) =>{
    try{
        const {apikey,product_id} = req.body;
        const product = await Product.findOne({
            where:{
                [Op.and]:[{product_id:product_id},{apikey:apikey}]

            }
          })
          if(product){
            next()
          }
          else{
      return res.status(409).send("Product security denied");
        
          }
         
    }catch(err){
        console.log(err);
    }
 }

 module.exports = {
    verifyProduct
   };
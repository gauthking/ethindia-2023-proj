const express = require('express')
const productAuth = require('../Middlewares/productAuth');
const userAuth = require('../Middlewares/userAuth')
const transactionController  = require('../Controllers/transactionController');
const  {
    addTransaction,getTransactions,updateTransaction
    } =transactionController;
const router =  express.Router()

//signup endpoint
//passing the middleware function to the signup
router.post('/add', userAuth.verifyUser, addTransaction)


//login route
router.post('/update', userAuth.verifyUser,productAuth.verifyProduct,updateTransaction )
router.get('/get',  userAuth.verifyUser,productAuth.verifyProduct,getTransactions )


module.exports = router
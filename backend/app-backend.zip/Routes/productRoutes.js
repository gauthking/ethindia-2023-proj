const express = require('express')
const userAuth = require('../Middlewares/userAuth')
const productController= require('../Controllers/productController');
const {
    addProduct,
    getProducts
   }=productController;
const router =  express.Router()

//passing the middleware function 
router.post('/add', userAuth.verifyUser, addProduct)


router.get('/get',  userAuth.verifyUser,getProducts )


module.exports = router